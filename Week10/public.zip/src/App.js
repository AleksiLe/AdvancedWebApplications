import logo from './logo.svg';
import './App.css';
import MyContainer from './components/MyContainer';

function App() {
  return (
    <div className="App">
      <h1>hello world</h1>
      <MyContainer
        />
    </div>
  );
}

export default App;
